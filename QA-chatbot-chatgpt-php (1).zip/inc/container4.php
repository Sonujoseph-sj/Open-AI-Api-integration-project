<link rel="icon" href="https://www.phpzag.com/wp-content/uploads/2019/05/cropped-cropped-coollogo_com-7816453-60x60-32x32.png" sizes="32x32" />
</head>
<body>
<nav class="navbar navbar-expand-md navbar-light" style="background-color: #73b2fc">
    <a href="https://www.phpzag.com" class="navbar-brand">PHPZAG.COM</a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav">
            <a href="https://www.phpzag.com" class="nav-item nav-link active">Home</a>            
        </div>       
    </div>
</nav>


	